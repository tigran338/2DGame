Read me File

Thanks for purchasing this Art Asset Pack hope you find it useful.
The downloadable file contains everything you need to start working right away on your game project.

Thanks Again

----------------

follow me at twitter @ansimuz

Visit my site for free resources at ansimuz.com

Support my work at Patreon and unlock more content patreon.com/ansimuz

----------------

Created by Ansimuz ansimuz.com
