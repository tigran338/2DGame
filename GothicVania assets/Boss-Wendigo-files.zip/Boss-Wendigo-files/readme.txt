Read me File

Thanks for purchasing this Art Asset Pack hope you find it useful.
The downloadable file contains everything you need to start working right away on your game project.

License
You may use these assets in personal or commercial projects. You may modify these assets to suit your needs. You can NOT re-distribute the file, no matter how much you modify it you can use it but not share or re-sell it.

Thanks Again

Created by Ansimuz www.ansimuz.com
Visit my site for free resources at www.pixelgameart.org

follow me at twitter @ansimuz