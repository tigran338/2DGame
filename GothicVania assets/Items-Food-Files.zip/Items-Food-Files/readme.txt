Items Food Read me File

Thanks for purchasing this Art Asset Pack hope you find it useful.

The downloadable file contains everything you need to start working right away on your project. I have included the PSD and the transparent PNG file format.

- Contents

-- PNG Folder: Contains the ready to use 

-- PSD Folder: Contains the Working PSD file.

-- SPRITES Folder: all the sliced sprites are store here in PNG format at 16x16 pixels.



Thanks Again

Visit my site for free resources at ansimuz.com